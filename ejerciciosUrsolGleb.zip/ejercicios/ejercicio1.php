
<?php

$nombre = 'denis';


echo "Hola, $nombre";


?>